#ket:
#p (rho) = Massa Jenis
# p = m/v

def massajenis(m,v):
    p = m/v
    return p
def massa(p,v):
    m = p*v
    return m
def volume(p,m):
    v = m/p
    return v
