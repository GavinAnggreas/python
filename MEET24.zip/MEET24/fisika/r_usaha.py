#ket:
#w = usaha
#f = gaya
# s = jarak

def usaha (f,s):
    return (f*s)
def gaya (w,s):
    return (w/s)
def jarak (w,f):
    return (w/f)