from .R_energiPotensial import energiPotensial as Ep
from .R_energiKinetik import energikinetik as Ek

