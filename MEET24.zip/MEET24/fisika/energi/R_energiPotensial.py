def energiPotensial (m,g,h):
    return m*g*h