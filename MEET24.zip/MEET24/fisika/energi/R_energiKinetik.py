def energikinetik(m,v):
    return (m*(v*v))/2;
