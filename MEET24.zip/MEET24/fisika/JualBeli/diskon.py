def diskon(n):
    def harga (a):
        return a * (100 - n)/100
    return harga